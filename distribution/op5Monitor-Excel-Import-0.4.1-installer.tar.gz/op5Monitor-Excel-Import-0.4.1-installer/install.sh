#!/bin/bash
CURRENTDIR=`pwd`
cp /etc/yum.conf local-yum.conf
echo "[op5-excel-import]" >>local-yum.conf
echo "name=op5 Excel Import" >>local-yum.conf
echo "gpgcheck=0" >>local-yum.conf
echo "enabled=1" >>local-yum.conf
echo "baseurl=file://${CURRENTDIR}/deps" >>local-yum.conf
if rpm --quiet -q op5Monitor-Excel-Import; then
	echo "doing an UPGRADE"
	yum -c local-yum.conf --enablerepo="op5-excel-import" localupdate op5Monitor-Excel-Import-*.rpm
else
	echo "doing an INSTALLATION"
	yum -c local-yum.conf --enablerepo="op5-excel-import" localinstall op5Monitor-Excel-Import-*.rpm
fi
